import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { Client } from 'colyseus.js';
import { ModelLocator } from '../ModelLocator/ModelLocator';
import { ReplaySubject } from 'rxjs';
import { Router } from '@angular/router';
import { playersvo } from '../vo/playersvo';
import { LocalDBService } from './local-db.service';


@Injectable({
  providedIn: 'root'
})
export class SocketconnectionService {
  socketHost = environment.socketHost;
  socketPort = environment.socketPort;
  client: any;
  currentGameStatus: any = "NONE";

  roomInterval:any

  public replacePlayerWithBot: ReplaySubject<{ [key: string]: string; }>;
  public updateRound: ReplaySubject<{ [key: string]: string; }>;
  public pointsUpdate: ReplaySubject<{ [key: string]: string; }>;
  public handWin: ReplaySubject<{ [key: string]: string; }>;
  public roundWin: ReplaySubject<{ [key: string]: string; }>;
  public gameWin: ReplaySubject<{ [key: string]: string; }>;
  public playedCard: ReplaySubject<{ [key: string]: string; }>;
  public updateCardStatus: ReplaySubject<{ [key: string]: string; }>;
  public myPlayingTurn: ReplaySubject<{ [key: string]: string; }>;
  public bidOptions: ReplaySubject<{ [key: string]: string; }>;
  public hideBidOptions: ReplaySubject<{ [key: string]: string; }>;
  public newCard: ReplaySubject<{ [key: string]: string; }>;
  public myTurn: ReplaySubject<{ [key: string]: string; }>;
  public bidWinner: ReplaySubject<{ [key: string]: string; }>;
  public leaveLobby: ReplaySubject<{ [key: string]: string; }>;
  public setLobbyObject: ReplaySubject<{ [key: string]: string; }>;
  public setRoomObject: ReplaySubject<{ [key: string]: string; }>;
  public newPlayerInGameSo: ReplaySubject<{ [key: string]: any; }>;
  public getPlayerBid: ReplaySubject<{ [key: string]: any; }>;
  public getDummyPlayerCard: ReplaySubject<{ [key: string]: any; }>;
  public getDouble: ReplaySubject<{ [key: string]: any; }>;
  public getReDouble: ReplaySubject<{ [key: string]: any; }>;
  public reDisrtibute: ReplaySubject<{ [key: string]: any; }>;
  public setBid: ReplaySubject<{ [key: string]: any; }>;
  public setMessage: ReplaySubject<{ [key: string]: any; }>;
  public nameDirection: ReplaySubject<{ [key: string]: any; }>;
  public gameTimer: ReplaySubject<{ [key: string]: any; }>;
  public playerJoinGame: ReplaySubject<string>;
  public playerLeave: ReplaySubject<{ [key: string]: any; }>;
  public startPrivateRoom: ReplaySubject<{ [key: string]: any; }>;
  public playerReconnect: ReplaySubject<{ [key: string]: any; }>;

  public lobby: any;
  public localData:any;


  constructor(public model: ModelLocator, public router: Router, public localDb:LocalDBService) {

    this.replacePlayerWithBot = new ReplaySubject<{ [key: string]: string; }>(1);
    this.updateRound = new ReplaySubject<{ [key: string]: string; }>(1);
    this.pointsUpdate = new ReplaySubject<{ [key: string]: string; }>(1);
    this.handWin = new ReplaySubject<{ [key: string]: string; }>(1);
    this.roundWin = new ReplaySubject<{ [key: string]: string; }>(1);
    this.gameWin = new ReplaySubject<{ [key: string]: string; }>(1);
    this.playedCard = new ReplaySubject<{ [key: string]: string; }>(1);
    this.updateCardStatus = new ReplaySubject<{ [key: string]: string; }>(1);
    this.myPlayingTurn = new ReplaySubject<{ [key: string]: string; }>(1);
    this.bidOptions = new ReplaySubject<{ [key: string]: string; }>(1);
    this.hideBidOptions = new ReplaySubject<{ [key: string]: string; }>(1);
    this.newCard = new ReplaySubject<{ [key: string]: string; }>(1);
    this.myTurn = new ReplaySubject<{ [key: string]: string; }>(1);
    this.leaveLobby = new ReplaySubject<{ [key: string]: string; }>(1);
    this.setLobbyObject = new ReplaySubject<{ [key: string]: string; }>(1);
    this.setRoomObject = new ReplaySubject<{ [key: string]: string; }>(1);
    this.newPlayerInGameSo = new ReplaySubject<{ [key: string]: any; }>(1);
    this.bidWinner = new ReplaySubject<{ [key: string]: any; }>(1);
    this.getPlayerBid = new ReplaySubject<{ [key: string]: any; }>(1);
    this.getDummyPlayerCard = new ReplaySubject<{ [key: string]: any; }>(1);
    this.getDouble = new ReplaySubject<{ [key: string]: any; }>(1);
    this.getReDouble = new ReplaySubject<{ [key: string]: any; }>(1);
    this.reDisrtibute = new ReplaySubject<{ [key: string]: any; }>(1);
    this.setBid = new ReplaySubject<{ [key: string]: any; }>(1);
    this.setMessage = new ReplaySubject<{ [key: string]: any; }>(1);
    this.nameDirection = new ReplaySubject<{ [key: string]: any; }>(1);
    this.gameTimer = new ReplaySubject<{ [key: string]: any; }>(1);
    this.playerJoinGame = new ReplaySubject<string>(1);
    this.playerLeave = new ReplaySubject<{ [key: string]: any; }>(1);
    this.startPrivateRoom = new ReplaySubject<{ [key: string]: any; }>(1);
    this.playerReconnect = new ReplaySubject<{ [key: string]: any; }>(1);

  }

  public connectServer(userObj: any): any {

    // const port = location.port ? ':' + location.port : '';
    const port = 'wss://api.anytimebridge.com/';
    // const port = 'ws://52.86.225.76:3001';

    // this.client = new Client(this.socketHost + this.socketPort);
    this.client = new Client(port);
    this.router.navigateByUrl('/random-game', { skipLocationChange: false });
    console.log("client is ", this.client, " port is ", port)
    if (userObj.isTimer) {
      this.client.joinOrCreate('tlobby', userObj).then((lobby: any) => {
        this.setLobbyObject.next(lobby);
        console.log("lobby Info >>", lobby);

        this.startLobby(lobby, 'random');

      }).catch((e: any) => {
        console.log("Lobby JOIN ERROR", e);
        alert("errror in connecting with lobby")
        // if(e == "DUPLICATE_USER")
        // this.router.navigateByUrl('/main-menu', { skipLocationChange: false });
      });
    }

    else if (!userObj.isTimer) {
      this.client.joinOrCreate('lobby', userObj).then((lobby: any) => {
        this.setLobbyObject.next(lobby);
        console.log("lobby Info >>", lobby);
        this.startLobby(lobby, 'random');

      }).catch((e: any) => {
        console.log("Lobby JOIN ERROR", e);
        alert("errror in connecting with lobby")
        // if(e == "DUPLICATE_USER")
        // this.router.navigateByUrl('/main-menu', { skipLocationChange: false });
      });
    }


  }

  async lobbyReconnect(roomId:any,sessionId:any){
    let temp;
    const port = 'wss://api.anytimebridge.com/';
    this.client = new Client(port);

    console.log("roomid and sessionId", roomId, sessionId);
    if (roomId.length > 0) {
      try {
        temp = await this.client.reconnect(roomId, sessionId);
        console.log("reconnection", temp);
       

       this.startLobby(temp,'random')
        // this.model.blackBg = false;
        // this.router.navigateByUrl('/game', { skipLocationChange: false });


      } catch (e) {
        console.log("error in reconnection ", e);
        
      }
    }

  }

  async reconnect(roomId: any, sessionId: any) {
    let temp;
    const port = 'wss://api.anytimebridge.com/';
    this.client = new Client(port);

    

    console.log("roomid and sessionId", roomId, sessionId);
    if (roomId.length > 0) {
      try {
        temp = await this.client.reconnect(roomId, sessionId);
        console.log("reconnection", temp);
        this.playerReconnect.next(temp);

        this.startGame(temp, 'Random');
        // this.model.blackBg = false;
        // this.router.navigateByUrl('/game', { skipLocationChange: false });


      } catch (e) {
        console.log("error in reconnection ", e);
        this.model.isReconnect = false;
      }
    }

  }


  startLobby(lobby: any, roomtype: any) {

    lobby.onMessage("JOINFINAL", (message: any) => {
      console.log(message.gamePlayerList);
      this.model.isReconnect=false;
      if (message.gamePlayerList.length <= 4) {
        this.model.playersInRoom = message.gamePlayerList;
        console.log("ALL PLAYERS", this.model.playersInRoom);
      }

    });

    lobby.onMessage("ROOMCONNECT", (message: any) => {
      console.log("Room Connected", message);
      this.model.teamName = message.team;
      this.model.seatOnServer = message.seat;
      this.model.userServerIndex = message.userIndex;
      lobby.leave();
      this.leaveLobby.next(message);
    });

    lobby.state.onChange = (changes: any) => {
      changes.forEach((change: any) => {
        // console.log("client left the lobb change ", change);
        switch (change.field) {
          case "waitTimerCount":
            break;
          case "status":

            break;
          case "winner":
            break;
          case "chatMessage":
            console.log("CHat log>>", change.value);
        }
      });
    };
    lobby.onLeave((code: any) => {
      console.log("client left the lobby random", code);
      // alert("lobby onleave")
    });

    console.log("Message >>>", lobby)

  }


  connectToPhaserRoom() {
    console.log("CONNECT TO PHASER ROOM", this.model.userId)


    this.client.consumeSeatReservation(this.model.seatOnServer).then((room: any) => {
      console.log("user joined game room successfully ", room);
      this.localData={"roomId":room.id,"sessionId":room.sessionId}
      this.model.roomId = room.id;
      this.setRoomObject.next(room);

      // this.gameStart.next(room);
      if (this.model.gameType == 'Friends') {
        this.startGame(room, 'friendInvite');
      }
      else {
        this.startGame(room, 'Random');
      }
    })
  }

  startGame(room: any, roomtype: any) {
    console.log('inside start game');
    this.model.gameRoom = room;
    
    this.model.isReconnect=false;


  //   this.model.roomInterval = setInterval(() => {
  //    room.send("pingRequest", { dbId: this.model.userId ,message:"Jay_Shree_Ram"})
  //   //  console.log("Jay_Shree_Ram");
  // }, 500)

//   room.onMessage("PONG", (message: any) => {
//     console.log("Pong Message : ",message);
// })

    room.onMessage("HANDWINNER", (message: any) => {
      console.log("handwinner animation >>", message);
      let map1: { [key: string]: string; } = {};
      map1['points'] = message.points;
      map1['myTeam'] = this.model.teamName;
      this.pointsUpdate.next(map1);

      let map2: { [key: string]: string; } = {};
      map2['seat'] = '0';
      for (let currentPlayer of this.model.allPlayers) {
        if (currentPlayer.index == message.winnerIndex) {
          map2['seat'] = currentPlayer.seat;
          break;
        }
      }
      console.log("map is ", map2)
      this.handWin.next(map2);
    });
    //BIDWINNER
    room.onMessage("BIDWINNER", (message: any) => {
      console.log("BIDWINNER animation >>", message);
      this.model.bidWin = true;
      this.bidWinner.next(message);
    });

    room.onMessage("BIDDETAILS", (message: any) => {
      console.log("BIDDETAILS >>", message);
      this.setBid.next(message);

    });
    room.onMessage("DUMMYPLAYER", (message: any) => {
      console.log("DUMMYPLAYER >>", message);
      this.model.DummyPlayerIndex = message.index;
      if (this.model.DummyPlayerIndex == this.model.userServerIndex)
        this.model.areYouDummy = true;
      this.getDummyPlayerCard.next(message);
      this.model.sortedArray = [];
      this.model.cardNewArray = [];

    });
    // On Player Leaveplayerlea

    room.onMessage("Leave_Player",(message:any)=>{

      console.log("Leave_Player",message);

      

      // this.messagePopup.message=message.userName+"Left the game!!!!!!"

      if(!message.consented && this.model.userId != message.dbId){
        
        if(this.model.isTimer){
          this.model.message=message.userName+" is offline. Cards will be played by server until player do not come online.";
          this.model.messageClose=true;
       
          this.model.messagePopupVisible=true;
          

        setTimeout(() => {
          this.model.messagePopupVisible=false;
          this.model.messageClose=false;
        }, 10000);
        }
        else if(!this.model.isTimer){
          this.model.message=message.userName+"  is offline. Please wait for player to join the game again.";
       
          this.model.messagePopupVisible=true;
          

        // setTimeout(() => {
        //   this.model.messagePopupVisible=false;
        // }, 10000);

        }
        // if(message){this.model.leavePlayerName.push(message.userName);}


      }


    if(this.model.leaveCount==0 && message.consented) { 
      this.model.message=message.userName+" Left, game ended";
      this.model.leaveCount++;
      this.model.messagePopupVisible=true;
      setTimeout(() => {
        this.model.messagePopupVisible=false;
      }, 5000);
      this.playerLeave.next(message);
}

     
    });

    // on Player Reconnected
    room.onMessage("player_Reconnected",(message:any)=>{
      console.log("player_Reconnected",message);
      
      {
        if(this.model.isTimer){
        this.model.messageClose=false;

      }
      this.model.messagePopupVisible=false;
    }
    

    });







    room.onMessage("DECLAREROUNDWINNER", (message: any) => {
      console.log("DECLAREROUNDWINNER popup >>", message, this.model.teamName);
      // let mapTeam: { [key: string]: any; } = {};
      // mapTeam['score'] = message.score;
      // mapTeam['points'] = message.points;
      // mapTeam['myTeam'] = this.model.teamName;
      // let round = {increaseRound: true};
      // console.log('here is the details', mapTeam);
      this.roundWin.next(message);
      // let mapTeam2: { [key: string]: any; } = {};
      // mapTeam2['increaseRound'] = "true";
      // this.updateRound.next(mapTeam2);
    });

    room.onMessage("DECLAREGAMEWINNER", (message: any) => {
      console.log("DECLAREGAMEWINNER popup >>", message, message.team);
      let mapTeam1: { [key: string]: any; } = {};
      mapTeam1['team'] = message.team;
      mapTeam1['score'] = message.score;
      mapTeam1['points'] = message.points;
      mapTeam1['myTeam'] = this.model.teamName;
      let winningPlayers = [];
      for (let person of this.model.allPlayers) {
        if (person.team == message.team) {
          winningPlayers.push(person.userName);
        }
      }
      mapTeam1['winningPlayers'] = winningPlayers;
      this.gameWin.next(message);
      let mapTeam2: { [key: string]: any; } = {};
      mapTeam2['increaseRound'] = "false";
      this.updateRound.next(mapTeam2);
    });

    room.onMessage("DISCONNECT", (message: any) => {

      this.router.navigateByUrl("");
      alert("Disconnect Room");

    });

    room.onMessage("REDISTRIBUTE", (message: any) => {
      var text: any = 1;
      this.reDisrtibute.next(text);
      this.model.cardDistibuted=false
      this.model.sortedArray = [];
      this.model.cardNewArray = [];
    });

    room.state.players.onAdd = (player: any, key: any) => {
      console.log(player, "has been added at", key);
      console.log("friends player>>>>", player, player.coin, player.userName);
      // this.model.friendProfile.push(player);
      let map: { [key: string]: string; } = {};
      map['playerName'] = player.userName;
      map['playerId'] = key;
      map['itsMe'] = 'false';
      map['type'] = "Random";
      map['userId'] = player.dbId;
      map['avatar'] = player.avatar;
      map['index'] = player.index;



      // let playerName:{[key:number]:string;}={};
      // playerName[player.index]= player.userName;
      // console.log("playerName--->",playerName);
      // this.model.playerNameData.push(playerName);

      // let playerDirection:{[key:number]:string;}={};
      // playerDirection[player.index]= player.direction;
      // console.log("playerDirection--->",playerDirection);
      // this.model.playerDirection.push(playerDirection);



      console.log(player.dbId, "comparing", this.model.userId, this.model.userServerIndex, "inside room connect");

      if (player.dbId == this.model.userId) {
        map['itsMe'] = 'true';
        this.model.teamName = player.team;
        // console.log("updating room connect index ", key)
        this.model.userServerIndex = player.index;
        map['chairId'] = '1';
      }
      else {
        console.log("user server index in switch ", this.model.userServerIndex)
        switch (this.model.userServerIndex.toString()) {
          case '0':
            // console.log("case 0 and key ", key)
            if (player.index == 2) {
              map['chairId'] = '2';
            }
            else if (player.index == 1) {
              map['chairId'] = '3';
            }
            else if (player.index == 3) {
              map['chairId'] = '4';
            }
            break;
          case '1':
            // console.log("case 1 and key ", key)
            if (player.index == 3) {
              map['chairId'] = '2';
            }
            else if (player.index == 2) {
              map['chairId'] = '3';
            }
            else if (player.index == 0) {
              map['chairId'] = '4';
            }
            break;
          case '2':
            // console.log("case 2 and key ", key)

            if (player.index == 0) {
              map['chairId'] = '2';
            }
            else if (player.index == 3) {
              map['chairId'] = '3';
            }
            else if (player.index == 1) {
              map['chairId'] = '4';
            }
            break;
          case '3':
            // console.log("case 3 and key ", key)
            if (player.index == 1) {
              map['chairId'] = '2';
            }
            else if (player.index == 0) {
              map['chairId'] = '3';
            }
            else if (player.index == 2) {
              map['chairId'] = '4';
            }
            break;
        }
      }

      let anObj = { userName: player.userName, index: player.index, team: player.team, userId: player.dbId, seat: map.chairId, avatar: map.avatar };
      // console.log("adding player ", player, map.chairId, key);
      this.model.allPlayers.push(anObj);
      this.newPlayerInGameSo.next(map);
      this.nameDirection.next(player);


      let self = this;
      player.onChange = function (changes: any) {
        console.log('this is the index of dummy player', changes);

        changes.forEach((change: any) => {
          switch (change.field) {
            case "Bid":

              // console.log("bidding details", change.value);

              if (change.value) {
                console.log('bidding details', changes.index, change.value, change);
                // self.bidOptions.next(change);
              }
              // UI.updateBid(player.index, change.value)
              break;
            case "points":
              // update points
              console.log(change.value, "change value point");
              // UI.updateTrickPoints(player.index, change.value);
              break;
            case "isBot":
              if (change.value) {
                console.log("is bot ", change.value, player.dbId);
                let map: { [key: string]: string; } = {};
                map['isBot'] = change.value;
                map['seat'] = '0';
                for (let currentPlayer of self.model.allPlayers) {
                  if (currentPlayer.userId == player.dbId) {
                    console.log("seat found ", currentPlayer.userId)
                    map['seat'] = currentPlayer.seat;
                    break;
                  }
                }
                self.replacePlayerWithBot.next(map);
              }
              // update bot status
              // UI.updateBotStatus(player.index, change.value, player.userName);
              break;

            case "cardPlayed":
              // update card played
              var card = change.value;
              console.log('here is the data of player>>>>>>>>>', change.value, self.model.allPlayers);
              if (change.value != null) {
                let map1: { [key: string]: string; } = {};
                map1['seat'] = '0';
                for (let currentPlayer of self.model.allPlayers) {
                  if (currentPlayer.userId == player.dbId) {
                    map1['seat'] = currentPlayer.seat;
                    break;
                  }
                }
                map1['card'] = change.value;
                console.log("card played ", card)

                
                  self.playedCard.next(map1);
                
                console.log("played server card received ", change.value.id)
              }
              break;

            case 'canDouble':

              if (self.model.userServerIndex == player.index) {
                console.log("Can Double is found", change.value, player.index, (self.model.userServerIndex == player.index));
                // if (this.model.allPlayers.length == 4) 
                self.getDouble.next(change.value);
              }


              break;

            case 'canReDouble':

              if (self.model.userServerIndex == player.index) {
                console.log("Can ReDouble is found", change.value);
                // if (this.model.allPlayers.length == 4) 
                self.getReDouble.next(change.value);
              }
          }



        });
      };
      console.log('this is the index of dummy player', this.model.bidWin);
      if (((this.model.userServerIndex == player.index) || ((this.model.userServerIndex + 2) == player.index) || ((this.model.userServerIndex - 2) == player.index))) {
        let self = this;
        player.cards.onAdd = function (card: any, key: any) {
          if (self.model.userServerIndex == player.index && (!self.model.cardDistibuted || self.model.isTimer)) {
            // 
            // this.localDb.setItem("CardDistribute", "");
            let map1: { [key: string]: string; } = {};
            map1['id'] = card.id;
            map1['value'] = card.card;
            map1['isActive'] = card.isActive;
            self.model.sortedArray.push(card.id);
            self.model.cardNewArray.push(map1);
            
            console.log('these are the cards that is develope',card.card, player.index,card);

            if (self.model.sortedArray.length > 12) {
              let lowestToHighest = self.model.sortedArray.sort((a: number, b: number) => b - a);
            self.model.cardDistibuted=true;

              for (var i = 0; i < self.model.cardNewArray.length; i++) {
                self.model.cardNewArray[i].id = lowestToHighest[i];
                self.newCard.next(self.model.cardNewArray[i]);
              }
              console.log('the sorted array is', lowestToHighest);
            }
            

            // self.newCard.next(map1);
          }

          card.onChange = function (changes: any) {
            changes.forEach((change: any) => {
              switch (change.field) {
                case "isActive":
                  let map1: { [key: string]: string; } = {};
                  map1['id'] = card.id;
                  map1['isActive'] = change.value;
                  map1['index'] = player.index;
                  self.updateCardStatus.next(map1);
                  console.log("change value >>>>", change);
                  console.log("card status updated", player.index);
                  // UI.setCard(change.value, card.id);
                  break;
              }
            });
          }

          // On Player Leave
        }
      }

      // else if (this.model.DummyPlayerIndex == player.index){
      //   alert('hello');
      // }



      room.state.players.onRemove = (player: any, key: any) => {
        console.log("players on remove ", player);
        // UI.removeGamePlayer(player, key);
      }
      room.onMessage("PLAYER_LEFT", (message: any) => {
        room.leave();
        alert("Game has completed");
        // location.reload();

      });



      player.triggerAll();

    };

    room.onError((code: any, message: any) => {
      console.log("oops, error ocurred:");
      console.log(message);
    });

    room.state.onChange = (changes: any) => {

      changes.forEach((change: any) => {
        console.log('these are the changes', change.field);
        switch (change.field) {
          case 'status':
            console.log("status >>", change);
            this.currentGameStatus = change.value;
            if (change.previousValue == "BIDDING") {
              this.hideBidOptions.next(change);
            }
            break;
          case 'turnIndex':
            console.log("turnIndex >>", change);
            let map: { [key: string]: string; } = {};
            map['playerIndex'] = change.value;
            map['seat'] = '0';
            for (let player of this.model.allPlayers) {
              if (player.index == change.value) {
                map['seat'] = player.seat;
                break;
              }
            }
            this.myTurn.next(map);



            console.log("status last >>", change.value, this.currentGameStatus);
            if (this.currentGameStatus == "BIDDING") {
              console.log('these are the hide options before if condition', change.value, this.model.userServerIndex);
              if (change.value == this.model.userServerIndex) {
                console.log('these are the hide options', change.value);
                this.bidOptions.next(change);
              }
              else {
                let map: { [key: string]: string; } = {};
                map['previousValue'] = change.previousValue;
                map['value'] = change.value;
                map['myIndex'] = this.model.userServerIndex;
                this.hideBidOptions.next(map);
              }
            }

            console.log('the value of the server index is', this.model.userServerIndex, change.value);
            if (this.currentGameStatus == "GAMEPLAY" && (change.value == this.model.userServerIndex || change.value == this.model.userServerIndex + 2 || change.value == this.model.userServerIndex - 2)) {
              console.log('I am inside the current game');
              this.myPlayingTurn.next(change.value);
            }
            break;

          case 'currentTurnTimer':
            console.log('these are the changes of the current Timer', change);
            this.gameTimer.next(change);
            break;


          case 'chatMessage':
            // Chat with player
            break;
          case 'teamScore':
            // update team score
            // console.log( "team Score >>", change.value ); 
            // UI.updateTeamScore(change.value);
            break;
        }
      });

    }

    room.onMessage('chatMessage', (message: any) => {
      console.log('here is the chat', message);
      this.setMessage.next(message);
    });

    room.state.teamScore.onChange = (changes: any) => {

      console.log("score changes >>>>>>", changes);
      changes.forEach((change: any) => {
        switch (change.field) {
          case 'A':
            console.log("team A score update", change.value)
            // UI.updateTeamScore( 'A', change.value )
            break;
          case 'B':
            console.log("team B score update", change.value)
            // UI.updateTeamScore( 'B', change.value );
            break;
        }
      });
    }
    if(!this.model.isReconnect){
      this.localDb.setSessionData(this.localData);
     }


  }

  ///////////////////////////Friends Room/////////
  public connectServerFriend(userObj: any): any {

    const port = 'wss://api.anytimebridge.com/';

    // this.client = new Client(this.socketHost + this.socketPort);
    this.client = new Client(port);
    this.router.navigateByUrl('new-game');

    this.client.create('friendInvite', userObj).then((lobby: any) => {
      this.setLobbyObject.next(lobby);
      console.log("lobby Info friend >>", lobby, this.setLobbyObject);
      // lobby.id = 'hello world';
      this.model.roomCodeToJoinAndShare = userObj.roomId;
      this.lobby = lobby;

      this.startLobbyFriend(lobby, 'Random');
    }).catch((e: any) => {
      console.log("Lobby JOIN ERROR", e);
      alert("errror in connecting with lobby");
    });
  }
  startLobbyFriend(friendsRoom: any, roomtype: any) {
    console.log("inside FriendsRoom", friendsRoom.onMessage);
    friendsRoom.state.players.onAdd = (player: any, key: any) => {
      console.log("125", player);
      this.updatePlayersInLobbyFriend(player);
      let map: { [key: string]: any; } = {};
      map['userName'] = player.userName;
      map['userId'] = player.dbId;
      map['isPartner'] = '';
      map['id'] = 0;
      this.model.gamePlayer.push(map);
      //friendsRoom.leave();
      this.updatePlayersInLobbyFriend(this.model.gamePlayer);
    }

    friendsRoom.state.players.onRemove = (player: any, key: any) => {
      console.log("player12560988", player);
      let map: { [key: string]: any; } = {};
      map['player'] = player;

      for (var i = 0; i < this.model.gamePlayer.length; i++) {
        if (this.model.gamePlayer[i].userId == player.dbId) {
          // this.model.playerLefted.push({playerId:this.model.gamePlayer[i].playerId,playerName:this.model.gamePlayer[i].playerName})
          this.model.gamePlayer.splice(i, 1)
        }
      }
      // this.playerLeave.next(map);
    }


    friendsRoom.onMessage("ROOM_CONNECT", (message: any) => {
      console.log("room connect ", message);
      console.log("ALL PLAYERS", this.model.playersInRoom);

      this.model.teamName = message.team;
      this.model.seatOnServer = message.seat;
      this.model.userServerIndex = message.userIndex;
      console.log(message.userIndex, "inside room connect");
      friendsRoom.leave();
      this.leaveLobby.next(message);
      this.model.players = [];
      this.model.roomName = "";
      this.model.roomCodeToJoinAndShare = 0;
    });




    friendsRoom.state.onChange = (changes: any) => {
      changes.forEach((change: any) => {
        // console.log("client left the lobb change ", change);
        switch (change.field) {
          case "waitTimerCount":
            break;
          case "status":

            break;
          case "winner":
            break;
          case "chatMessage":
            console.log("CHat log>>", change.value);
        }
      });
    };

    friendsRoom.onLeave((code: any) => {
      console.log("client left the lobby", code);
      // alert("lobby onleave")
    });
  }

  updatePlayersInLobbyFriend(playerDetails: any) {
    console.log("players are ", playerDetails);
    const p: playersvo[] = [];
    if (this.model.players.length != this.model.gamePlayer) {
      this.model.players = []
      this.model.hostPlayer = this.model.gamePlayer[0];
      for (let player of this.model.gamePlayer) {
        const participant: playersvo = new playersvo(player.userName, player.id, player.userId, player.isPartner);
        this.model.players.push(participant);
        console.log(this.model.players, "this.model.players");
      }
      this.model.playersInRoom = this.model.gamePlayer;
      if (this.model.playersInRoom.length == 4) {
        // this.startPrivateRoom.next();
        console.log('here is the value of lobby', this.lobby);
        // this.lobby.send('PLAYER_JOINED', {message: 'hello'});
        this.startPrivateRoom.next();
        //this.model.ga

      }
    }
  }



  public joinFriendsRoom(userObj: any, roomId: any) {
    console.log("inside funcnjoin friend")
    const port = 'wss://api.anytimebridge.com/';

    // this.client = new Client(this.socketHost + this.socketPort);
    this.client = new Client(port);
    let roomExist = false;

    this.client.getAvailableRooms("friendInvite").then((rooms: any) => {
      console.log("rooms are ", rooms)
      if (rooms.length == 0) {
        console.log("")
        // this.friendsInvitesocketService.roomErrorMessage.next(true);
      }
      else {
        for (var i = 0; i < rooms.length; i++) {
          console.log("matching rooms ", rooms[i].metadata.data[0].roomcode, "and ", roomId)
          // if (rooms[i].metadata.customRoomCode == roomId) {
          if (rooms[i].metadata.data[0].roomcode == roomId) {
            roomExist = true;
            this.client.joinById(rooms[i].roomId, userObj).then((lobby: any) => {
              //this.setFriendsRoomObject.next(lobby);
              this.setLobbyObject.next(lobby);
              console.log("lobby joined successfully >>", lobby);
              this.startFriendsRoom(lobby, 'Random');
              this.router.navigateByUrl('/join-game', { skipLocationChange: false });
              // this.router.navigateByUrl('/', { skipLocationChange: false });

            }).catch((e: any) => {
              console.log("JOIN friendivite ERROR", e);

              //this.friendsInvitesocketService.roomErrorMessage.next(true);
            });
          }
          else if (!roomExist && i == (rooms.length - 1)) {
            console.log("elseif 595");
            //this.friendsInvitesocketService.roomErrorMessage.next(true);
          }
        }

      }


    }).catch((e: any) => {
      console.log("get avl rooms friendivite ERROR", e);
      alert("room join error")
      // this.friendsInvitesocketService.roomErrorMessage.next(true);
    });

  }

  startFriendsRoom(friendsRoom: any, roomType: any) {
    friendsRoom.state.players.onAdd = (player: any, key: any) => {
      let map: { [key: string]: any; } = {};
      map['userName'] = player.userName;
      map['userId'] = player.dbId;
      map['isPartner'] = '';
      map['id'] = 0;
      this.model.gamePlayer.push(map);

      this.updatePlayersInLobbyFriend(this.model.gamePlayer);
      console.log(player, "player628");

      player.onChange = (changes: any) => {
        console.log("player property changed ", changes)


        changes.forEach((change: any) => {
          console.log("player changed ", change)

          switch (change.field) {

            case "isPartner":
              console.log("isPartner changed ", change.value, key, player.dbId)
              break;
            case "directReshuffle":
              break;
            case "isBot":
              break;
          }
        });
      }
      player.triggerAll();
    }
    // console.log("room state ", friendsRoom.state);

    friendsRoom.onMessage("ROOM_CONNECT", (message: any) => {
      console.log("room connect ", message);

      console.log("Timer===>",message.isTimer);
      this.model.isTimer=message.isTimer;

      console.log("ALL PLAYERS", this.model.playersInRoom);
      // this.startPrivateRoom.next();

      this.model.teamName = message.team;
      this.model.seatOnServer = message.seat;
      this.model.userServerIndex = message.userIndex;
      console.log(message.userIndex, "inside room connect");
      friendsRoom.leave();
      this.leaveLobby.next(message);
      this.model.players = [];
      this.model.roomName = "";
      this.model.roomCodeToJoinAndShare = 0;
    });


    friendsRoom.state.onChange = (changes: any) => {
      changes.forEach((change: any) => {
        console.log("client lobb change ", change);
        switch (change.field) {
          case "waitTimerCount":
            break;
          case "status":
            break;
          case "winner":
            break;
          case "chatMessage":
            console.log("CHat log>>", change.value);
            break;
          case "customRoomCode":
            console.log("room code found ", change.value);
            this.model.roomCodeToJoinAndShare = change.value;
            break;
        }
      });
    };

    friendsRoom.state.players.onRemove = (player: any, key: any) => {
      console.log("player12560988", player);
      let map: { [key: string]: any; } = {};
      map['player'] = player;

      for (var i = 0; i < this.model.gamePlayer.length; i++) {
        if (this.model.gamePlayer[i].userId == player.dbId) {
          // this.model.playerLefted.push({playerId:this.model.gamePlayer[i].playerId,playerName:this.model.gamePlayer[i].playerName})
          this.model.gamePlayer.splice(i, 1)
        }
      }
      // this.playerLeave.next(map);
    }

    friendsRoom.onLeave((code: any) => {
      console.log("client left the lobby", code);
      // this.insideGame = false;
      // alert("friends lobby onleave")
    });
  }




}


