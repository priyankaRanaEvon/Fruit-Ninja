import { Playersvo } from './playersvo';

describe('Playersvo', () => {
  it('should create an instance', () => {
    expect(new Playersvo()).toBeTruthy();
  });
});
