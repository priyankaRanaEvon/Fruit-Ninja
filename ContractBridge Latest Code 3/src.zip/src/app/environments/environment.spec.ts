import { Environment } from './environment';

describe('Environment', () => {
  it('should create an instance', () => {
    expect(new Environment()).toBeTruthy();
  });
});
