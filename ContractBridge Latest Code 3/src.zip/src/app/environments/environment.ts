export const environment = {
    production: false,
    socketHost: 'ws://localhost',
    socketPort: '3001',
    host: 'http://3.130.228.54:3000/api/'
  };
  